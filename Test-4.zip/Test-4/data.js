const data = {
    users: [
      { id: 1, name: 'John', age: 30, email: 'john@gmail.com' },
      { id: 2, name: 'Joseph', age: 24, email: 'joseph@gmail.com' },
      { id: 3, name: 'Charlie', age: 28, email: 'charlie@gmail.com' },
      { id: 4, name: 'Jay', age: 28, email: 'jay@gmail.com' },
      { id: 5, name: 'George', age: 28, email: 'george@gmail.com' },
      { id: 6, name: 'Sam', age: 28, email: 'sam@gmail.com' },
      { id: 7, name: 'Roy', age: 28, email: 'roy@gmail.com' },
      { id: 8, name: 'Ganny', age: 28, email: 'ganny@gmail.com' },
      { id: 9, name: 'Precious', age: 28, email: 'precious@gmail.com' },
      { id: 10, name: 'Najima', age: 28, email: 'najima@gmail.com' },


    ],
    products: [
      { PID: 1, name: 'Laptop', price: 1000 },
      { PID: 4, name: 'Smartphone', price: 800 },
      { PID: 5, name: 'Tablet', price: 600 },
      { PID: 2, name: 'Airpod', price: 300 },
      { PID: 6, name: 'Watch', price: 700 },
      { PID: 7, name: 'Camera', price: 1500 },

    ],
  };
  
  module.exports = data;
  